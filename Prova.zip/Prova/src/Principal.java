
public class Principal {
	public static void main(String[] args){
		int len = (int)(Math.random() * 15) + 1;
		Pessoa[] ps = new Pessoa[len];


		for (int i = 0; i < ps.length; i++) {
			int qi = (int)(Math.random() * 140) + 1;
			if(qi >= 110){
				ps[i] = new Mulher("Mulher " + i, (int)(Math.random() * 50) + 18, qi, "Profissao " + i);				
			} else {
				int idade = (int)(Math.random() * 50) + 18;
				ps[i] = new Homem("Homem "+ i ,idade , qi, new Data(i, (int)(Math.random() * 12) + 1, 2016 - idade));
			}
		}

		for (int i = 0; i < ps.length; i++) {
			if(ps[i] instanceof Mulher)
				System.out.println("A mulher de nome "+ ps[i].getNome() +" est� no array");
		}

		System.out.println("\n \n Todos homens que nasceram ap�s 1985");
		for (int i = 0; i < ps.length; i++) {
			if(ps[i] instanceof Homem && (2016 - ps[i].getIdade()) > 1985)
				System.out.println(ps[i]);				
		}

		Mulher qiAlto = null;
		for (int i = 0; i < ps.length; i++) {
			if(ps[i] instanceof Mulher)
				if(qiAlto == null)
					qiAlto = (Mulher)ps[i];
				else if (ps[i].getQi() > qiAlto.getQi())
					qiAlto = (Mulher)ps[i];
		}
		
		if(qiAlto != null){
			System.out.println("\n \n \n A Profiss�o da mulher com QI mais alto �: " + qiAlto.getProfissao());
		}
		
		System.out.println("\n \n \n Data de nascimento de homens com QI nas faixas D e E");
		for (int i = 0; i < ps.length; i++) {
			if(ps[i] instanceof Homem){
				if(ps[i].getQi()  > 79)
					System.out.println(((Homem)ps[i]).getNascimento());
			}
		}
		
		System.out.println("\n \n \n Remover todas as pessoas com QI nas faixas B,C e D");
		
		for (int i = 0; i < ps.length; i++) {

			int qi = ps[i].getQi();
			if(qi <= 129 && qi > 89){				
				System.out.println("Pessoa "+ ps[i].getNome() + "(sexo" + (ps[i] instanceof Homem ? " Homem" : " Mulher") + ") foi removida");
				ps[i] = null;				
			}
		}

		for (int i = 0; i < ps.length; i++) {
			ps = tiraPessoas(ps);
		}
	}

	private static Pessoa[] tiraPessoas(Pessoa[] ps){
		for (int i = 0; i < ps.length; i++) {
			if(i + 1 < ps.length  && ps[i] == null && ps[i+1] != null){
				ps[i] = ps[i+1];
				ps[i+1] = null;
			}
		}
		return ps;
	}

}
