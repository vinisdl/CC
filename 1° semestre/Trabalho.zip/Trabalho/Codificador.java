public class Codificador{
  private String tabelaCodificacao;
    
    public Codificador(String tabelaCodificacao){
        this.tabelaCodificacao = tabelaCodificacao;
    }
    
    public String getTabelaCodificacao(){
        return this.tabelaCodificacao;
    }
    
    public void setTabelaCodificacao(String tabelaCodificacao){
        this.tabelaCodificacao = tabelaCodificacao;
    }
    
    public String toString(){
        int aux = 1;
        String tabela = "|     |  1  |  2  | 3   |  4  |  5  | "; 
        for(int i = 0; i < tabelaCodificacao.length(); i++){
            if( i % 5 == 0){                
                tabela += "\n|  "+ aux +"  ";
                aux++;
            }             
                tabela += "|  " + tabelaCodificacao.charAt(i) + "  ";            
        }        
        return "Tabela de codificacao: \n" + tabela; 
    }   
}