public class Carta{
    private String naipe;
    private int num;
    
    public Carta(String naipe, int num){
        this.naipe = naipe;
        this.num = num;        
    }
    
    public void setNaipe(String naipe){
        this.naipe = naipe;
    }
    
    public void setNum(int num){
        this.num = num;
    }
    
    public String getNaipe(){
        return this.naipe;
    }
    
    public int getNum(){
        return this.num;
    }
    
    public String toString(){
        return "Naipe: " + this.naipe + "\n Número: "+ this.num;
    }
    
}