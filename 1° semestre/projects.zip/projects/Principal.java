public class Principal{
    public static void main(String[] args){
        String nomeFirst = T.leString("Digite o nome do primeiro jogador");
        String nomeSecond = T.leString("Digite o nome do segundo jogador");
        String nomeThird = T.leString("Digite o nome do terceiro jogador");
        Jogador first = new Jogador(nomeFirst,T.leInt("Digite a idade do primeiro jogador"),0);
        Jogador second = new Jogador(nomeSecond,T.leInt("Digite a idade do terceiro jogador"),0);
        Jogador third = new Jogador(nomeThird,T.leInt("Digite a idade do terceiro jogador"),0);
        boolean marcador = true;
        if(!(nomeFirst.equalsIgnoreCase(nomeSecond) 
            && nomeFirst.equalsIgnoreCase(nomeThird) 
            && nomeSecond.equalsIgnoreCase(nomeThird))){             
        } else {
            System.out.println("Existem nomes iguais");
            while(marcador){
                if(nomeFirst.equalsIgnoreCase(nomeSecond)){
                    int val = T.leInt("Digite 1 para editar o primeiro e 2 para o segundo");
                    switch(val){
                        case 1:
                            nomeFirst = T.leString("Digite o nome do primeiro jogador");
                            break;
                        case 2:
                            nomeSecond =  T.leString("Digite o nome do segundo jogador");
                            break;
                        default:
                            System.out.println("Valor incorreto");
                    }                   
                } else if(nomeFirst.equalsIgnoreCase(nomeThird)){
                    int val = T.leInt("Digite 1 para editar o primeiro e 2 para o Terceiro");
                    switch(val){
                        case 1:
                            nomeFirst = T.leString("Digite o nome do primeiro jogador");
                            break;
                        case 2:
                            nomeThird =  T.leString("Digite o nome do segundo jogador");
                            break;
                        default:
                            System.out.println("Valor incorreto");
                    }
                } else if(nomeSecond.equalsIgnoreCase(nomeThird)) {
                    int val = T.leInt("Digite 1 para editar o Segundo e 2 para o Terceiro");
                    switch(val){
                        case 1:
                            nomeSecond = T.leString("Digite o nome do primeiro jogador");
                            break;
                        case 2:
                            nomeThird =  T.leString("Digite o nome do segundo jogador");
                            break;
                        default:
                            System.out.println("Valor incorreto");
                    }
                } else if (!(nomeFirst.equalsIgnoreCase(nomeSecond) 
                        && nomeFirst.equalsIgnoreCase(nomeThird) 
                        && nomeSecond.equalsIgnoreCase(nomeThird))){
                     first = new Jogador(nomeFirst,0,0);
                     second = new Jogador(nomeSecond,0,0);
                     third = new Jogador(nomeThird,0,0);
                     marcador = false;
                }                
            }                
        }  
        
        first = jogadorPegaCarta(first);
        second = jogadorPegaCarta(second);
        third = jogadorPegaCarta(third);
        
        if(first.getTentativas() < second.getTentativas() && first.getTentativas() < third.getTentativas()){
            System.out.println(first);
        } else if(first.getTentativas() > second.getTentativas() && second.getTentativas() < third.getTentativas()){
            System.out.println(second);
        } else {
            System.out.println(third);
        }
        
        
    }   
    
    public static Jogador jogadorPegaCarta(Jogador jogador){
        do{
            jogador.pegaCarta();
            jogador.setTentativas(jogador.getTentativas() +1);            
        } while(!(jogador.getCarta().getNaipe().equals("Ouro") 
                && jogador.getCarta().getNum() == 7));
                
        return jogador;
    }
}        
