
public class Mulher extends Pessoa {
	private String profissao;

	public Mulher(String nome, int idade, int qi, String profissao) {
		super(nome, idade, qi);
		this.profissao = profissao;
	}

	public String getProfissao() {
		return profissao;
	}

	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}

	@Override
	public String toString() {
		return "Mulher [profissao=" + profissao + ", " + super.toString() + "]";
	}
	
	
}
