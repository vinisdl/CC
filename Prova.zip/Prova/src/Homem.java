
public class Homem extends Pessoa {
	private Data nascimento;

	public Homem(String nome, int idade, int qi, Data nascimento) {
		super(nome, idade, qi);
		this.nascimento = nascimento;
	}

	public Data getNascimento() {
		return nascimento;
	}

	public void setNascimento(Data nascimento) {
		this.nascimento = nascimento;
	}

	@Override
	public String toString() {
		return "Homem [nascimento=" + nascimento + ", " + super.toString() + "]";
	}
	
	
}
