import java.util.Scanner;

public class Principal {
	public static void main(String[] args){
		Cor[] coresSorteadas = new Cor[4];
		boolean ganhou = false;
		coresSorteadas = sorteiaCor(coresSorteadas);

		Fase[] fases = new Fase[10];
		for (int i = 0; i < fases.length; i++) {
			fases[i] = new Fase(i + 1);
		}

		String nomeJogador; 
		do{
			nomeJogador = getString();
		}
		while(nomeJogador == null);

		for (int i = 0; i < fases.length; i++) {
			if(!ganhou){
				System.out.println("Bem vindo ao jogo MasterMind voc� est� na fase " + fases[i].getFase());
				System.out.println("Voc� tera que escolher 4 cores");
				System.out.println("- Verde (V)");
				System.out.println("- Azul (A)");
				System.out.println("- Marrom (M)");
				System.out.println("- Rosa (R)");
				System.out.println("- Preto (P)");
				System.out.println("- Branco (B)");
				System.out.println("- Dourado (D)");
				System.out.println("- Lil�s (L)");

				Cor[] corSelect = new Cor[4];

				
				for (int j = 0; i < corSelect.length; i++) {
					Cor corSor;
					do{
						System.out.println("Digite a inical da cor");
						char c = getChar();
						corSor = new Cor().setCor(c);						
					}while( verificaSeTem(corSor, corSelect) != -1);
					corSelect[j] = corSor;
					
				}
				fases[i].setCores(corSelect);
				if(fases[i].getCores().equals(coresSorteadas)){
					ganhou = true;
				} else {
					int index;
					for (int j = 0; j < corSelect.length; j++) {
						index = verificaSeTem(corSelect[i], coresSorteadas);
						if(index == j){
							fases[i].setCoresCertasPosicaoCerta();
						}else if( index != -1){
							fases[i].setCoresCertasPosicaoCerta();
						}
					}
				}
			}

		}
		
		if(ganhou){
			for (int i = 0; i < 10; i++) {
				System.out.println("\n");
			}
			System.out.println("Parab�ns voc� Ganhou!".toUpperCase());
		} else {
			System.out.println("Fases Jogadas at� agora;");
			for (int i = 0; i < fases.length; i++) {
				if(fases[i].getCores()[0] != null){
					System.out.println(fases[i]);
				}
			}
		}





	}

	public static char getChar(){
		String op;
		do{
			op = getString();

		}while(op == null);
		return op.toLowerCase().charAt(0);
	}

	public static Cor[] sorteiaCor(Cor[] coresSorteadas){

		for (int i = 0; i < coresSorteadas.length; i++) {
			Cor corSor;
			do{
				int op = (int)(Math.random() * 8 + 1);
				corSor = new Cor().setCor(op);	
			}
			while(verificaSeTem(corSor, coresSorteadas) != -1);

			coresSorteadas[i] = corSor;
		}
		return coresSorteadas;
	}

	public static int verificaSeTem(Cor corSor, Cor[] coresSorteadas){
		int tem = -1;
		for (int j = 0; j < coresSorteadas.length; j++) {			
			if(coresSorteadas[j] != null && coresSorteadas[j].equals(corSor)){
				tem = j;
			}				
		}
		return tem;
	}

	public static String getString(){
		try
		{
			Scanner s = new Scanner(System.in);
			return s.next();
		}
		catch(Exception e)
		{
			return null;
		}		
	}



}
