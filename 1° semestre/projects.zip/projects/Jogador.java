public class Jogador{
    private String nome;
    private int idade,tentativas;
    private Carta carta;
    
    public Jogador(String nome, int idade, int tentativas){
        this.nome = nome;
        this.idade = idade;
        this.tentativas = tentativas;
        this.carta = null;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setIdade(int idade){
        this.idade = idade;
    }
    
    public void setTentativas(int tentativas){
        this.tentativas = tentativas;
    }
    
    public void setCarta(Carta carta){
        this.carta = carta;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public int getIdade(){
        return this.idade;
    }
    
    public int getTentativas(){
        return this.tentativas;
    }
    
    public Carta getCarta(){
        return this.carta;
    }
    
    public String toString(){
        return "Nome: "+ this.nome + "\n Idade: " + this.idade
            + "\n Número de tentativas: "
            + this.tentativas + "\n Carta: \n " + (this.carta != null ? this.carta : "Jogador sem carta");
    }
    
    public void pegaCarta(){
        int valNaipe = (int)(Math.random()*4 + 1);
        int numCarta = (int)(Math.random() * 12 + 1);
        switch(valNaipe){
            case 1:
                this.carta = new Carta("Copas", numCarta);
                break;
            case 2:
                this.carta = new Carta("Ouro", numCarta);
                break;
            case 3:
                this.carta = new Carta("Paus", numCarta);
                break;
            case 4:
                this.carta = new Carta("Espadas", numCarta);
                break;                        
        }
    
    }
    
}
