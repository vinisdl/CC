
public class Cor {
	
	private String nome;
	
	public Cor(){		
	}
	
	public Cor(String nome){
		this.nome = nome;
	}
	
	
	public String getNome(){
		return this.nome;
	}
	
	
	
	@Override
	public String toString() {
		return "Cor [nome=" + nome + "]";
	}

	public Cor setCor(int v){
		switch (v) {
		case 1:
			this.nome = "Verde";
			return this;
		case 2:
			this.nome = "Azul";
			return this;
		case 3:
			this.nome = "Marrom";
			return this;
		case 4:
			this.nome = "Rosa";
			return this;
		case 5:
			this.nome = "Preto";
			return this;
		case 6:
			this.nome = "Branco";
			return this;
		case 7:
			this.nome = "Dourado";
			return this;
		case 8:
			this.nome = "Lil�s";
			return this;
		default:
			return null;
		}			
	}
	
	public Cor setCor(char v){
		switch (v) {
		case 'V':
			this.nome = "Verde";
			return this;
		case 'A':
			this.nome = "Azul";
			return this;
		case 'M':
			this.nome = "Marrom";
			return this;
		case 'R':
			this.nome = "Rosa";
			return this;
		case 'P':
			this.nome = "Preto";
			return this;
		case 'B':
			this.nome = "Branco";
			return this;
		case 'D':
			this.nome = "Dourado";
			return this;
		case 'L':
			this.nome = "Lil�s";
			return this;
		default:
			return null;
		}			
	}
}
