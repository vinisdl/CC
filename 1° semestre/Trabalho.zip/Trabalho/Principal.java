public class Principal{
    public static void main(String[] args){
        
            Codificador cod = new Codificador("abcdefghijklmnopqrstuvxyz.,!?1");
  System.out.println(cod);
}
}