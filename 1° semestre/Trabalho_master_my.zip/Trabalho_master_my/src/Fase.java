import java.util.Arrays;

public class Fase {
	private int fase, coresCertasPosicaoErrada, coresCertasPosicaoCerta;
	private Cor[] cores;
		
	public Fase(int fase) {		
		this.fase = fase;
		this.coresCertasPosicaoErrada = 0;
		this.coresCertasPosicaoCerta = 0;
		this.cores = new Cor[4];
	}
	
	@Override
	public String toString() {
		String cor = "";
		for (int i = 0; i < cores.length; i++) {
			cor += "\n " + cores[i]; 
		}
		
		return "Fase [fase=" + fase + ", coresCertasPosicaoErrada=" + coresCertasPosicaoErrada
				+ ", coresCertasPosicaoCerta=" + coresCertasPosicaoCerta + ", cores=" + cor + "]";
	}

	public int getFase() {
		return fase;
	}
	public void setFase(int fase) {
		this.fase = fase;
	}
	public int getCoresCertasPosicaoErrada() {
		return coresCertasPosicaoErrada;
	}
	public void setCoresCertasPosicaoErrada() {
		this.coresCertasPosicaoErrada++;
	}
	public int getCoresCertasPosicaoCerta() {
		return coresCertasPosicaoCerta;
	}
	public void setCoresCertasPosicaoCerta() {
		this.coresCertasPosicaoCerta++;
	}
	public Cor[] getCores() {
		return cores;
	}
	public void setCores(Cor[] cores) {
		this.cores = cores;
	}
	
}

